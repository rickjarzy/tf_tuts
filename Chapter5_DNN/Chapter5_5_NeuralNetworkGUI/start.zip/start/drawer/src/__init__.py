from .dnn import nn_predict
from .dnn import nn_train
from .drawing_gui import main_gui
