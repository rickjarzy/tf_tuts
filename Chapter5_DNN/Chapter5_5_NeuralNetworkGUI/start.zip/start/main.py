from drawer import main_gui


if __name__ == "__main__":
    main_gui()
